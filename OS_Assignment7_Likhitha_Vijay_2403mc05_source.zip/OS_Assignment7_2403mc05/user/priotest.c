// Author: Likhitha Vijay | Roll No: 2403mc05 | OS Lab Assignment 7
// Q4(e): fork 4 CPU-bound processes with distinct priorities, print the
// completion order, and show that the lowest priority one does not starve.
// (Kernel prints "[aging] ..." lines whenever aging raises a priority.)
#include "types.h"
#include "stat.h"
#include "user.h"

#define NPROCS 4
#define WORK   300000000          // iterations of the CPU-bound loop per child

int prios[NPROCS] = {2, 8, 14, 20};      // 1 = highest, 20 = lowest

int
main(int argc, char *argv[])
{
  int i, j, pid, start, fd[2];
  int pids[NPROCS];
  int msg[3];                      // child -> parent: {index, final priority, finish tick}
  volatile int x = 1;

  // The parent runs at the highest priority (1) while it forks, so all four
  // children exist before any of them starts running.
  set_priority(getpid(), 1);
  pipe(fd);
  start = uptime();
  printf(1, "priotest: parent pid %d running at priority %d, start tick %d\n",
         getpid(), get_priority(getpid()), start);

  for(i = 0; i < NPROCS; i++){
    pid = fork();
    if(pid < 0){
      printf(1, "fork failed\n");
      exit();
    }
    if(pid == 0){
      // ---- child: CPU-bound loop, report result to parent through the pipe ----
      // (priority was already set by the parent; setting it again here would undo any aging)
      for(j = 0; j < WORK; j++)
        x = x * 3 + 1;
      msg[0] = i;
      msg[1] = get_priority(getpid());       // priority after aging
      msg[2] = uptime();
      write(fd[1], msg, sizeof(msg));        // one write -> one atomic message
      exit();
    }
    pids[i] = pid;
    set_priority(pid, prios[i]);
    printf(1, "  forked pid %d with priority %d\n", pid, prios[i]);
  }

  // parent now sleeps in wait(); the children compete
  for(i = 0; i < NPROCS; i++){
    pid = wait();
    read(fd[0], msg, sizeof(msg));
    printf(1, "COMPLETION #%d: pid %d  initial priority %d  final (aged) priority %d  finished at tick %d\n",
           i + 1, pid, prios[msg[0]], msg[1], msg[2] - start);
  }
  printf(1, "priotest done: the priority-20 process also completed -> no starvation\n");
  exit();
}
