// Author: Likhitha Vijay | Roll No: 2403mc05 | OS Lab Assignment 7
// Q1(e): 3 threads created with clone(), each increments a shared global
// counter 100,000 times WITHOUT synchronization, then join() each.
#include "types.h"
#include "stat.h"
#include "user.h"

#define PGSIZE   4096
#define NTHREADS 3
#define ITERS    100000
#define WORKLOAD 40              // small busy loop that widens the race window (identical in threadtest.c / synctest.c)

volatile int counter = 0;        // shared global (same address space for all threads)

void
worker(void *arg)
{
  int id = (int)arg;
  int i, k, tmp;
  volatile int *c = &counter;
  volatile int d;

  for(i = 0; i < ITERS; i++){
    tmp = *c;                    // load
    tmp = tmp + 1;               // modify
    for(k = 0; k < WORKLOAD; k++) d = k;   // simulated work inside the read-modify-write window
    *c = tmp;                    // store   (read-modify-write is NOT atomic -> race)
  }
  printf(1, "  thread %d (pid %d) finished its loop\n", id, getpid());
  exit();                        // a thread ends with exit(); join() reaps it
}

int
main(int argc, char *argv[])
{
  int i, pid;
  void *raw[NTHREADS];
  void *stack;

  printf(1, "threadtest: creating %d threads, each does %d increments\n", NTHREADS, ITERS);
  for(i = 0; i < NTHREADS; i++){
    raw[i] = malloc(2 * PGSIZE);                       // over-allocate, then align to a page
    stack = (void*)(((uint)raw[i] + PGSIZE - 1) & ~(PGSIZE - 1));
    pid = clone(worker, (void*)i, stack);
    if(pid < 0){
      printf(1, "clone failed\n");
      exit();
    }
    printf(1, "  created thread %d with pid %d\n", i, pid);
  }

  for(i = 0; i < NTHREADS; i++){
    pid = join();
    printf(1, "  joined thread pid %d\n", pid);
  }

  printf(1, "Final counter value : %d\n", counter);
  printf(1, "Expected value      : %d\n", NTHREADS * ITERS);
  if(counter != NTHREADS * ITERS)
    printf(1, "RACE CONDITION: lost %d updates (no synchronization)\n", NTHREADS * ITERS - counter);
  else
    printf(1, "(no updates lost this run - races are non-deterministic)\n");
  for(i = 0; i < NTHREADS; i++)
    free(raw[i]);
  exit();
}
