// Author: Likhitha Vijay | Roll No: 2403mc05 | OS Lab Assignment 7
// Q3: Deadlock detection + Banker's algorithm (deadlock avoidance) in xv6 user space.
#include "types.h"
#include "stat.h"
#include "user.h"

#define MAXP 5
#define MAXR 3

// ------------------------------------------------------------------
// printing helpers
// ------------------------------------------------------------------
void
print_vec(int v[], int m)
{
  int j;
  printf(1, "[");
  for(j = 0; j < m; j++)
    printf(1, "%d%s", v[j], j == m - 1 ? "" : " ");
  printf(1, "]");
}

// Prints Available, Allocation and the third matrix (Request or Need).
void
print_state(int n, int m, int avail[], int alloc[][MAXR], int third[][MAXR], char *third_name)
{
  int i;
  printf(1, "  Available = "); print_vec(avail, m); printf(1, "\n");
  printf(1, "  Process   Allocation   %s\n", third_name);
  for(i = 0; i < n; i++){
    printf(1, "  P%d        ", i);
    print_vec(alloc[i], m);
    printf(1, "    ");
    print_vec(third[i], m);
    printf(1, "\n");
  }
}

// ------------------------------------------------------------------
// Q3(b): Deadlock DETECTION.
//   Finish[i] starts true only for processes holding nothing.  Repeatedly
//   find an unfinished process whose Request <= Work, pretend it finishes
//   and release its allocation.  Whatever is still unfinished is deadlocked.
//   Returns the number of deadlocked processes; their ids go in dead[].
// ------------------------------------------------------------------
int
detect_deadlock(int n, int m, int avail[], int alloc[][MAXR], int req[][MAXR], int dead[])
{
  int work[MAXR], finish[MAXP];
  int i, j, found, ndead, ok;

  for(j = 0; j < m; j++)
    work[j] = avail[j];
  for(i = 0; i < n; i++){
    finish[i] = 1;
    for(j = 0; j < m; j++)
      if(alloc[i][j] != 0)
        finish[i] = 0;
  }

  do {
    found = 0;
    for(i = 0; i < n; i++){
      if(finish[i])
        continue;
      ok = 1;
      for(j = 0; j < m; j++)
        if(req[i][j] > work[j])
          ok = 0;
      if(ok){
        for(j = 0; j < m; j++)
          work[j] += alloc[i][j];
        finish[i] = 1;
        found = 1;
        printf(1, "    P%d's request can be met -> P%d finishes, Work = ", i, i);
        print_vec(work, m);
        printf(1, "\n");
      }
    }
  } while(found);

  ndead = 0;
  for(i = 0; i < n; i++)
    if(!finish[i])
      dead[ndead++] = i;
  return ndead;
}

void
run_detection(char *title, int n, int m, int avail[], int alloc[][MAXR], int req[][MAXR])
{
  int dead[MAXP], nd, i;

  printf(1, "\n--- %s ---\n", title);
  print_state(n, m, avail, alloc, req, "Request");
  nd = detect_deadlock(n, m, avail, alloc, req, dead);
  if(nd == 0){
    printf(1, "  RESULT: no deadlock (system is not deadlocked)\n");
  } else {
    printf(1, "  RESULT: DEADLOCK detected, deadlocked processes:");
    for(i = 0; i < nd; i++)
      printf(1, " P%d", dead[i]);
    printf(1, "\n");
  }
}

// ------------------------------------------------------------------
// Q3(d): Banker's algorithm.
// ------------------------------------------------------------------
int g_n, g_m;
int g_avail[MAXR];
int g_alloc[MAXP][MAXR];
int g_max[MAXP][MAXR];
int g_need[MAXP][MAXR];

void
compute_need(void)
{
  int i, j;
  for(i = 0; i < g_n; i++)
    for(j = 0; j < g_m; j++)
      g_need[i][j] = g_max[i][j] - g_alloc[i][j];
}

// Safety algorithm on the current global state; fills seq[] if safe.
int
is_safe_state(int seq[])
{
  int work[MAXR], finish[MAXP];
  int i, j, found, ok, cnt = 0;

  for(j = 0; j < g_m; j++)
    work[j] = g_avail[j];
  for(i = 0; i < g_n; i++)
    finish[i] = 0;

  do {
    found = 0;
    for(i = 0; i < g_n; i++){
      if(finish[i])
        continue;
      ok = 1;
      for(j = 0; j < g_m; j++)
        if(g_need[i][j] > work[j])
          ok = 0;
      if(ok){
        for(j = 0; j < g_m; j++)
          work[j] += g_alloc[i][j];
        finish[i] = 1;
        seq[cnt++] = i;
        found = 1;
      }
    }
  } while(found);

  return cnt == g_n;
}

void
print_seq(int seq[])
{
  int i;
  printf(1, "<");
  for(i = 0; i < g_n; i++)
    printf(1, "P%d%s", seq[i], i == g_n - 1 ? "" : ", ");
  printf(1, ">");
}

// Hypothetical request: grant only if the resulting state is safe.
// Returns 1 if granted, 0 if refused (state is rolled back).
int
request_resources(int pid, int req[])
{
  int j, seq[MAXP];

  printf(1, "\n  P%d requests ", pid); print_vec(req, g_m); printf(1, "\n");
  for(j = 0; j < g_m; j++){
    if(req[j] > g_need[pid][j]){
      printf(1, "  -> DENIED: request exceeds P%d's declared maximum claim\n", pid);
      return 0;
    }
  }
  for(j = 0; j < g_m; j++){
    if(req[j] > g_avail[j]){
      printf(1, "  -> P%d must WAIT: resources not available\n", pid);
      return 0;
    }
  }
  // pretend to allocate
  for(j = 0; j < g_m; j++){
    g_avail[j] -= req[j];
    g_alloc[pid][j] += req[j];
    g_need[pid][j] -= req[j];
  }
  printf(1, "  hypothetical state after granting:\n");
  print_state(g_n, g_m, g_avail, g_alloc, g_need, "Need");
  if(is_safe_state(seq)){
    printf(1, "  -> GRANTED: state is SAFE, safe sequence "); print_seq(seq); printf(1, "\n");
    return 1;
  }
  // roll back
  for(j = 0; j < g_m; j++){
    g_avail[j] += req[j];
    g_alloc[pid][j] -= req[j];
    g_need[pid][j] += req[j];
  }
  printf(1, "  -> DENIED: granting would lead to an UNSAFE state (possible deadlock), request rolled back\n");
  return 0;
}

void
load_banker_example(void)
{
  int A[MAXP][MAXR] = {{0,1,0},{2,0,0},{3,0,2},{2,1,1},{0,0,2}};
  int M[MAXP][MAXR] = {{7,5,3},{3,2,2},{9,0,2},{2,2,2},{4,3,3}};
  int V[MAXR] = {3,3,2};
  int i, j;
  g_n = 5; g_m = 3;
  for(j = 0; j < 3; j++) g_avail[j] = V[j];
  for(i = 0; i < 5; i++)
    for(j = 0; j < 3; j++){
      g_alloc[i][j] = A[i][j];
      g_max[i][j] = M[i][j];
    }
  compute_need();
}

// ------------------------------------------------------------------
// Q3(c): a REAL deadlock with xv6 processes and pipes.
//   Resource R0 = "write end of pipe1", R1 = "write end of pipe2" (1 instance each).
//   Process A holds pipe1's write end and blocks reading pipe2.
//   Process B holds pipe2's write end and blocks reading pipe1.
//   Each child reports (holds, wants) through a report pipe before blocking;
//   the parent builds Allocation/Request from those reports.
// ------------------------------------------------------------------
void
real_deadlock(void)
{
  int p1[2], p2[2], rep[2];
  int a, b, i;
  int msg[3];
  char c;
  int avail[MAXR] = {0, 0, 0};
  int alloc[MAXP][MAXR], req[MAXP][MAXR];
  int pids[2];

  printf(1, "\n=== Test 4: REAL deadlock with two xv6 processes and pipes ===\n");
  for(i = 0; i < MAXP; i++){
    alloc[i][0] = alloc[i][1] = alloc[i][2] = 0;
    req[i][0] = req[i][1] = req[i][2] = 0;
  }
  pipe(p1); pipe(p2); pipe(rep);

  a = fork();
  if(a == 0){                                   // ---- Process A ----
    msg[0] = 0; msg[1] = 0; msg[2] = 1;         // A: holds R0 (pipe1 write end), wants R1
    write(rep[1], msg, sizeof(msg));
    read(p2[0], &c, 1);                         // blocks: only B could write pipe2, but B is blocked too
    write(p1[1], "x", 1);                       // never reached
    exit();
  }
  b = fork();
  if(b == 0){                                   // ---- Process B ----
    msg[0] = 1; msg[1] = 1; msg[2] = 0;         // B: holds R1 (pipe2 write end), wants R0
    write(rep[1], msg, sizeof(msg));
    read(p1[0], &c, 1);                         // blocks: only A could write pipe1, but A is blocked too
    write(p2[1], "x", 1);                       // never reached
    exit();
  }
  pids[0] = a; pids[1] = b;
  printf(1, "  started A (pid %d): holds pipe1.write, waits to read pipe2\n", a);
  printf(1, "  started B (pid %d): holds pipe2.write, waits to read pipe1\n", b);

  for(i = 0; i < 2; i++){
    read(rep[0], msg, sizeof(msg));
    alloc[msg[0]][msg[1]] = 1;                  // process msg[0] holds resource msg[1]
    req[msg[0]][msg[2]] = 1;                    // ... and requests resource msg[2]
  }
  sleep(50);                                    // give both children time to block in read()
  printf(1, "  after 50 ticks neither process has made progress -> analysing the wait-for state\n");
  run_detection("Test 4 state built from real processes (P0 = A, P1 = B)", 2, 2, avail, alloc, req);

  // clean up the stuck processes
  kill(a); kill(b);
  wait(); wait();
  printf(1, "  killed the deadlocked processes %d and %d (deadlock broken)\n", pids[0], pids[1]);
}

int
main(int argc, char *argv[])
{
  int seq[MAXP];
  int i, j;

  // ---------------- Test 1: SAFE (no deadlock) ----------------
  {
    int avail[MAXR] = {0, 0, 0};
    int alloc[MAXP][MAXR] = {{0,1,0},{2,0,0},{3,0,3},{2,1,1},{0,0,2}};
    int req[MAXP][MAXR]   = {{0,0,0},{2,0,2},{0,0,0},{1,0,0},{0,0,2}};
    printf(1, "=== Test 1: deadlock detection, expected NO deadlock ===");
    run_detection("Test 1", 5, 3, avail, alloc, req);
  }

  // ---------------- Test 2: DEADLOCKED ----------------
  {
    int avail[MAXR] = {0, 0, 0};
    int alloc[MAXP][MAXR] = {{0,1,0},{2,0,0},{3,0,3},{2,1,1},{0,0,2}};
    int req[MAXP][MAXR]   = {{0,0,0},{2,0,2},{0,0,1},{1,0,0},{0,0,2}};   // P2 now also wants one C
    printf(1, "\n=== Test 2: deadlock detection, expected DEADLOCK ===");
    run_detection("Test 2", 5, 3, avail, alloc, req);
  }

  // ---------------- Test 3: Banker's algorithm ----------------
  printf(1, "\n=== Test 3: Banker's algorithm (deadlock avoidance) ===\n");
  load_banker_example();
  printf(1, "\n--- Initial state ---\n");
  print_state(g_n, g_m, g_avail, g_alloc, g_need, "Need");
  if(is_safe_state(seq)){
    printf(1, "  Initial state is SAFE, safe sequence "); print_seq(seq); printf(1, "\n");
  } else
    printf(1, "  Initial state is UNSAFE\n");

  {
    int r1[MAXR] = {1, 0, 2};
    int r2[MAXR] = {0, 2, 0};
    int r3[MAXR] = {3, 3, 0};
    request_resources(1, r1);      // safe  -> granted
    request_resources(4, r3);      // more than available -> must wait
    request_resources(0, r2);      // leads to an unsafe state -> denied
  }
  (void)i; (void)j;

  // ---------------- Test 4: real processes + pipes ----------------
  real_deadlock();
  exit();
}
