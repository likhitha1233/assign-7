// Author: Likhitha Vijay | Roll No: 2403mc05 | OS Lab Assignment 7
// Q2(d): threadtest.c fixed with a semaphore (mutex).
// Q2(e): classic Producer-Consumer with semaphores empty / full / mutex.
#include "types.h"
#include "stat.h"
#include "user.h"

#define PGSIZE   4096
#define NTHREADS 3
#define ITERS    100000
#define WORKLOAD 40              // small busy loop that widens the race window (identical in threadtest.c / synctest.c)

// semaphore ids
#define S_COUNTER 0              // binary semaphore guarding the counter
#define S_MUTEX   1              // producer/consumer: guards the buffer
#define S_EMPTY   2              // producer/consumer: number of empty slots (starts at 5)
#define S_FULL    3              // producer/consumer: number of full slots  (starts at 0)

#define BUFSZ  5
#define NITEMS 12

volatile int counter = 0;

void
counter_worker(void *arg)
{
  int i, k, tmp;
  volatile int *c = &counter;
  volatile int d;

  for(i = 0; i < ITERS; i++){
    sem_wait(S_COUNTER);         // enter critical section
    tmp = *c;
    tmp = tmp + 1;
    for(k = 0; k < WORKLOAD; k++) d = k;   // same simulated work as threadtest.c
    *c = tmp;
    sem_signal(S_COUNTER);       // leave critical section
  }
  exit();
}

// ---------------- Producer / Consumer ----------------
int buffer[BUFSZ];
int in = 0, out = 0;
volatile int count = 0;          // items currently in the buffer (for the log only)

void
producer(void *arg)
{
  int i;
  for(i = 1; i <= NITEMS; i++){
    sem_wait(S_EMPTY);           // wait for a free slot
    sem_wait(S_MUTEX);
    buffer[in] = i;
    count++;
    printf(1, "[producer] produced item %d -> slot %d   (items in buffer: %d)\n", i, in, count);
    if(count > BUFSZ) printf(1, "ERROR: buffer overflow!\n");
    in = (in + 1) % BUFSZ;
    sem_signal(S_MUTEX);
    sem_signal(S_FULL);          // one more full slot
  }
  exit();
}

void
consumer(void *arg)
{
  int i, item;
  for(i = 1; i <= NITEMS; i++){
    sleep(2);                    // consumer is slower, so the buffer fills up and the producer blocks
    sem_wait(S_FULL);            // wait for an item
    sem_wait(S_MUTEX);
    item = buffer[out];
    count--;
    printf(1, "[consumer] consumed item %d <- slot %d   (items in buffer: %d)\n", item, out, count);
    if(count < 0) printf(1, "ERROR: buffer underflow!\n");
    out = (out + 1) % BUFSZ;
    sem_signal(S_MUTEX);
    sem_signal(S_EMPTY);         // one more empty slot
  }
  exit();
}

void*
newstack(void **raw)
{
  *raw = malloc(2 * PGSIZE);
  return (void*)(((uint)*raw + PGSIZE - 1) & ~(PGSIZE - 1));
}

int
main(int argc, char *argv[])
{
  int i;
  void *raw[NTHREADS], *praw, *craw;

  // ---------- Part 1: race condition fixed ----------
  printf(1, "=== Part 1: shared counter protected by a semaphore ===\n");
  sem_init(S_COUNTER, 1);
  for(i = 0; i < NTHREADS; i++)
    clone(counter_worker, 0, newstack(&raw[i]));
  for(i = 0; i < NTHREADS; i++)
    join();
  printf(1, "Final counter value : %d\n", counter);
  printf(1, "Expected value      : %d\n", NTHREADS * ITERS);
  if(counter == NTHREADS * ITERS)
    printf(1, "SUCCESS: counter is exact with synchronization\n");
  else
    printf(1, "FAILURE: counter is wrong\n");
  for(i = 0; i < NTHREADS; i++)
    free(raw[i]);

  // ---------- Part 2: producer-consumer ----------
  printf(1, "\n=== Part 2: Producer-Consumer (buffer size %d, %d items) ===\n", BUFSZ, NITEMS);
  sem_init(S_MUTEX, 1);
  sem_init(S_EMPTY, BUFSZ);
  sem_init(S_FULL, 0);
  clone(producer, 0, newstack(&praw));
  clone(consumer, 0, newstack(&craw));
  join();
  join();
  printf(1, "Producer-Consumer finished: all %d items produced and consumed, final occupancy %d\n",
         NITEMS, count);
  free(praw);
  free(craw);
  exit();
}
