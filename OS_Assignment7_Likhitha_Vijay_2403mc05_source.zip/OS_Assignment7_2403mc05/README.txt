OS Lab Assignment 7 (xv6)  -  Likhitha Vijay, Roll No 2403mc05
Base: MIT xv6-public.  Copy kernel/* and user/* over the xv6-public tree, then:  make qemu-nox
(Makefile: sem.o added to OBJS; _threadtest _synctest _deadlock _priotest added to UPROGS; -Werror removed for newer gcc.)
Run inside xv6:  threadtest | synctest | deadlock | priotest   (priotest was run with CPUS=1:  make qemu-nox CPUS=1)
