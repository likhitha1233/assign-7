// Author: Likhitha Vijay | Roll No: 2403mc05 | OS Lab Assignment 7
// Q2: kernel counting semaphores built on xv6's sleep()/wakeup().
#include "types.h"
#include "defs.h"
#include "param.h"
#include "memlayout.h"
#include "mmu.h"
#include "x86.h"
#include "proc.h"
#include "spinlock.h"

#define NSEM 10                  // fixed-size semaphore array (Q2 c)

struct semaphore {
  int value;                     // current count
  int inuse;                     // has sem_init() been called for this slot?
  struct spinlock lk;            // protects 'value'
};

// The global table.  table.lock protects slot allocation/initialisation;
// each semaphore's own lk protects its counter and the sleep/wakeup.
struct {
  struct spinlock lock;
  struct semaphore sem[NSEM];
} semtable;

void
seminit(void)
{
  int i;
  initlock(&semtable.lock, "semtable");
  for(i = 0; i < NSEM; i++){
    initlock(&semtable.sem[i].lk, "sem");
    semtable.sem[i].value = 0;
    semtable.sem[i].inuse = 0;
  }
}

// int sem_init(int sem_id, int value): initialise semaphore sem_id.
int
semaphore_init(int id, int value)
{
  struct semaphore *s;

  if(id < 0 || id >= NSEM || value < 0)
    return -1;
  acquire(&semtable.lock);
  s = &semtable.sem[id];
  acquire(&s->lk);
  s->value = value;
  s->inuse = 1;
  release(&s->lk);
  release(&semtable.lock);
  return 0;
}

// int sem_wait(int sem_id): P() operation.  Blocks (sleeps) while the
// count is not positive, then decrements it.  Re-checking the condition
// in a while loop makes wakeups safe even if another process grabs the
// token first, so no wakeup can be lost and the value never goes negative.
int
semaphore_wait(int id)
{
  struct semaphore *s;

  if(id < 0 || id >= NSEM)
    return -1;
  s = &semtable.sem[id];
  acquire(&s->lk);
  if(!s->inuse){
    release(&s->lk);
    return -1;
  }
  while(s->value <= 0){
    if(myproc()->killed){
      release(&s->lk);
      return -1;
    }
    sleep(s, &s->lk);            // atomically releases s->lk and sleeps
  }
  s->value--;
  release(&s->lk);
  return 0;
}

// int sem_signal(int sem_id): V() operation.  Increments the count and
// wakes processes sleeping on this semaphore.
int
semaphore_signal(int id)
{
  struct semaphore *s;

  if(id < 0 || id >= NSEM)
    return -1;
  s = &semtable.sem[id];
  acquire(&s->lk);
  if(!s->inuse){
    release(&s->lk);
    return -1;
  }
  s->value++;
  wakeup(s);                     // wake a waiter, if any
  release(&s->lk);
  return 0;
}
